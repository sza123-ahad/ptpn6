import * as Ladda from 'ladda';

window.Ladda = Ladda;
